(function () { 
    if (!mstrmojo.plugins.ZoomableSunburst) {
        mstrmojo.plugins.ZoomableSunburst = {};
    }

    mstrmojo.requiresCls(
        "mstrmojo.vi.models.editors.CustomVisEditorModel",
        "mstrmojo.array"
    );

    mstrmojo.plugins.ZoomableSunburst.ZoomableSunburstEditorModel = mstrmojo.declare(
        mstrmojo.vi.models.editors.CustomVisEditorModel,
        null,
        {
            scriptClass: "mstrmojo.plugins.ZoomableSunburst.ZoomableSunburstEditorModel",
            cssClass: "zoomablesunbursteditormodel",
            getCustomProperty: function getCustomProperty(){









}
})}());
//@ sourceURL=ZoomableSunburstEditorModel.js